

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

// Encrypt or decrypt a source string using XOR and a provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();
    assert(key_length > 0 && source_length > 0);

    std::string output = source;

    // XOR encryption/decryption
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);
    return output;
}

// Read the content of a text file into a string
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file)
    {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return "";
    }

    std::ostringstream content;
    content << file.rdbuf(); // Read the file into a string stream
    return content.str();
}

// Save formatted data to a text file
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);
    if (!file)
    {
        std::cerr << "Error: Unable to open file " << filename << std::endl;
        return;
    }

    // Get the current timestamp
    std::time_t now = std::time(nullptr);
    std::tm time_info;
    localtime_s(&time_info, &now);  // Safer alternative to localtime()
    char timestamp[20];
    std::strftime(timestamp, sizeof(timestamp), "%Y-%m-%d", &time_info);

    // Write the formatted data to the file
    file << student_name << '\n'
        << timestamp << '\n'
        << key << '\n'
        << data << '\n';
}

// Extract the student name from the file content (first line)
std::string get_student_name(const std::string& string_data)
{
    size_t pos = string_data.find('\n');
    return (pos != std::string::npos) ? string_data.substr(0, pos) : "";
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key = "password";

    // Read input data file
    const std::string source_string = read_file(file_name);
    if (source_string.empty())
    {
        std::cerr << "Error: Source string is empty. Exiting program." << std::endl;
        return 1;
    }

    // Extract the student name
    const std::string student_name = get_student_name(source_string);

    // Encrypt the source string using the key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted string to a file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt the encrypted string using the same key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted string to a file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name
        << " - Encrypted To: " << encrypted_file_name
        << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu


