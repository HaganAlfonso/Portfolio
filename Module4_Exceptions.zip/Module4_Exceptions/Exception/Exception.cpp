#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
	const char* what() const throw () {
		return "Custom Exception triggered";
	}
};

// Function to handle potential divide by zero error using a standard C++ exception
float divide(float num, float den) {
	if (den == 0) {
		throw std::runtime_error("Attempted to divide by zero.");
	}
	return num / den;
}

// Wrapper function to handle exception from divide function
void do_division() noexcept {
	float numerator = 10.0f;
	float denominator = 0;

	try {
		auto result = divide(numerator, denominator);
		std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
	}
	catch (const std::exception& e) {
		std::cout << "Exception occurred: " << e.what() << std::endl;
	}
}

// Function that throws a standard exception
bool do_even_more_custom_application_logic() {
	throw std::logic_error("Simulated error in logic.");
	return true;
}

// Function wrapping call to another function that throws an exception
void do_custom_application_logic() {
	std::cout << "Running Custom Application Logic." << std::endl;

	try {
		if (do_even_more_custom_application_logic()) {
			std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
		}
	}
	catch (const std::exception& e) {
		std::cout << "Error: " << e.what() << std::endl;
	}

	std::cout << "Leaving Custom Application Logic." << std::endl;
}

// Main function that orchestrates the exception handling across multiple functions
int main() {
	try {
		do_division();
		do_custom_application_logic();
		throw CustomException();
	}
	catch (const CustomException& e) {
		std::cout << "Caught Custom Exception: " << e.what() << std::endl;
	}
	catch (const std::exception& e) {
		std::cout << "Caught std::exception: " << e.what() << std::endl;
	}
	catch (...) {
		std::cout << "Caught unhandled exception." << std::endl;
	}

	return 0;
}
